"""Trains all 5 ML models used by the combined app and saves them to model/."""
import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error, r2_score
from sklearn.preprocessing import LabelEncoder

os.makedirs("model", exist_ok=True)
RF_KWARGS = dict(n_estimators=50, max_depth=14, random_state=42)

# ---------- 1. Crop recommendation ----------
df = pd.read_csv("dataset/crop_data.csv").dropna()
FEATURES = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
encoder = LabelEncoder()
y = encoder.fit_transform(df["label"])
X = df[FEATURES]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model = RandomForestClassifier(**RF_KWARGS)
model.fit(Xtr, ytr)
print("[crop] accuracy:", round(accuracy_score(yte, model.predict(Xte)), 4))
joblib.dump({"model": model, "encoder": encoder, "features": FEATURES}, "model/crop_model.pkl")

# ---------- 2. Irrigation ----------
df = pd.read_csv("dataset/irrigation_data.csv")
need_encoder = LabelEncoder()
df["crop_water_need_enc"] = need_encoder.fit_transform(df["crop_water_need"])
FEATURES = ["soil_moisture_pct", "temperature_c", "humidity_pct", "rain_forecast_mm", "crop_water_need_enc"]
X = df[FEATURES]
y_clf = df["irrigate"]
Xtr, Xte, ytr, yte = train_test_split(X, y_clf, test_size=0.2, random_state=42, stratify=y_clf)
clf = RandomForestClassifier(**RF_KWARGS)
clf.fit(Xtr, ytr)
print("[irrigation] decision accuracy:", round(accuracy_score(yte, clf.predict(Xte)), 4))
irrigated = df[df["irrigate"] == 1]
Xr, yr = irrigated[FEATURES], irrigated["water_liters"]
Xtr2, Xte2, ytr2, yte2 = train_test_split(Xr, yr, test_size=0.2, random_state=42)
reg = RandomForestRegressor(**RF_KWARGS)
reg.fit(Xtr2, ytr2)
print("[irrigation] water MAE:", round(mean_absolute_error(yte2, reg.predict(Xte2)), 2))
joblib.dump({"clf": clf, "reg": reg, "need_encoder": need_encoder, "features": FEATURES}, "model/irrigation_model.pkl")

# ---------- 3. Fertilizer ----------
df = pd.read_csv("dataset/fertilizer_data.csv")
soil_enc = LabelEncoder(); crop_enc = LabelEncoder(); fert_enc = LabelEncoder()
df["Soil_Type_enc"] = soil_enc.fit_transform(df["Soil_Type"])
df["Crop_Type_enc"] = crop_enc.fit_transform(df["Crop_Type"])
y = fert_enc.fit_transform(df["Fertilizer_Name"])
FEATURES = ["Temperature", "Humidity", "Moisture", "Soil_Type_enc", "Crop_Type_enc", "Nitrogen", "Phosphorous", "Potassium"]
X = df[FEATURES]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model = RandomForestClassifier(**RF_KWARGS)
model.fit(Xtr, ytr)
print("[fertilizer] accuracy:", round(accuracy_score(yte, model.predict(Xte)), 4))
joblib.dump({"model": model, "soil_encoder": soil_enc, "crop_encoder": crop_enc, "fert_encoder": fert_enc, "features": FEATURES}, "model/fertilizer_model.pkl")

# ---------- 4. Yield ----------
df = pd.read_csv("dataset/yield_data.csv")
crop_enc2 = LabelEncoder(); season_enc = LabelEncoder(); state_enc = LabelEncoder()
df["Crop_enc"] = crop_enc2.fit_transform(df["Crop"])
df["Season_enc"] = season_enc.fit_transform(df["Season"])
df["State_enc"] = state_enc.fit_transform(df["State"])
FEATURES = ["Crop_enc", "Season_enc", "State_enc", "Area_hectare", "Rainfall_mm", "Fertilizer_kg_per_ha", "Pesticide_kg_per_ha"]
X = df[FEATURES]; y = df["Yield_tons_per_ha"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestRegressor(**RF_KWARGS)
model.fit(Xtr, ytr)
print("[yield] R^2:", round(r2_score(yte, model.predict(Xte)), 4))
joblib.dump({"model": model, "crop_encoder": crop_enc2, "season_encoder": season_enc, "state_encoder": state_enc, "features": FEATURES}, "model/yield_model.pkl")

# ---------- 5. Market price ----------
import numpy as np
df = pd.read_csv("dataset/price_history.csv", parse_dates=["Date"]).sort_values(["Commodity", "Date"]).reset_index(drop=True)
frames = []
for commodity, g in df.groupby("Commodity"):
    g = g.copy()
    g["lag_1"] = g["Price_per_kg"].shift(1)
    g["lag_7"] = g["Price_per_kg"].shift(7)
    g["lag_14"] = g["Price_per_kg"].shift(14)
    g["rolling_mean_7"] = g["Price_per_kg"].shift(1).rolling(7).mean()
    g["day_of_year"] = g["Date"].dt.dayofyear
    g["target_next_day"] = g["Price_per_kg"].shift(-1)
    frames.append(g)
full = pd.concat(frames).dropna().reset_index(drop=True)
commodity_enc = LabelEncoder()
full["Commodity_enc"] = commodity_enc.fit_transform(full["Commodity"])
FEATURES = ["Commodity_enc", "lag_1", "lag_7", "lag_14", "rolling_mean_7", "day_of_year"]
X = full[FEATURES]; y = full["target_next_day"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)
model = RandomForestRegressor(**RF_KWARGS)
model.fit(Xtr, ytr)
print("[price] R^2:", round(r2_score(yte, model.predict(Xte)), 4))
latest = full.groupby("Commodity").tail(1).set_index("Commodity")[["Price_per_kg", "lag_1", "lag_7", "lag_14", "rolling_mean_7", "day_of_year"]]
joblib.dump({"model": model, "commodity_encoder": commodity_enc, "features": FEATURES, "latest_by_commodity": latest}, "model/price_model.pkl")

print("\nAll 5 models trained and saved to model/.")
