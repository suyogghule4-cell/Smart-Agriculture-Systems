// Auto-dismiss flash alerts after a few seconds
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".alert").forEach((el) => {
    setTimeout(() => {
      el.style.transition = "opacity 0.5s ease";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 500);
    }, 4000);
  });

  // Basic client-side validation for the prediction form
  const predictForm = document.getElementById("predict-form");
  if (predictForm) {
    predictForm.addEventListener("submit", (e) => {
      const inputs = predictForm.querySelectorAll("input[required]");
      let valid = true;
      inputs.forEach((input) => {
        if (input.value.trim() === "" || isNaN(parseFloat(input.value))) {
          valid = false;
          input.style.borderColor = "#c1440e";
        } else {
          input.style.borderColor = "#cdd8d0";
        }
      });
      if (!valid) {
        e.preventDefault();
        alert("Please enter valid numeric values for all fields.");
      }
    });
  }
});
