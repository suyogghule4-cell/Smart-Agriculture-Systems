"""Utility package: database helpers + auth decorators for the combined app."""
import os
import secrets
import sqlite3
from functools import wraps
from datetime import datetime

from flask import session, redirect, url_for, flash

# Set DB_PATH to a persistent location on hosting (e.g. /var/data/app.db).
DB_PATH = os.environ.get("DB_PATH") or os.path.join(os.path.dirname(os.path.dirname(__file__)), "database", "app.db")


def get_db():
    # timeout: wait if another worker process is writing (gunicorn starts several).
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    # Unified activity log across all 6 predictive tools (crop, disease,
    # irrigation, fertilizer, yield, price). Each row = one user action.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            tool TEXT NOT NULL,
            summary TEXT NOT NULL,
            details TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    # Separate table for the live farm-monitor stream (continuous sensor
    # readings, not discrete user actions like the tools above).
    cur.execute("""
        CREATE TABLE IF NOT EXISTS readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            zone TEXT, soil_moisture REAL, temperature REAL, humidity REAL, co2_ppm REAL,
            has_alert INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)
    conn.commit()

    cur.execute("SELECT COUNT(*) AS c FROM users WHERE is_admin = 1")
    if cur.fetchone()["c"] == 0:
        from werkzeug.security import generate_password_hash
        password = os.environ.get("ADMIN_PASSWORD")
        if not password:
            # No hardcoded default: generate a random one and show it once in the log.
            password = secrets.token_urlsafe(12)
            print(f"[setup] No ADMIN_PASSWORD set. Generated admin password: {password}")
            print("[setup] Save it now, or set ADMIN_PASSWORD and delete the database to re-create the admin.")
        # OR IGNORE: several worker processes may run this at the same time.
        cur.execute(
            "INSERT OR IGNORE INTO users (username, email, password_hash, is_admin, created_at) VALUES (?, ?, ?, 1, ?)",
            ("admin", "admin@example.com", generate_password_hash(password), datetime.utcnow().isoformat()),
        )
        conn.commit()

    conn.close()


def log_activity(user_id, tool, summary, details=""):
    conn = get_db()
    conn.execute(
        "INSERT INTO activities (user_id, tool, summary, details, created_at) VALUES (?, ?, ?, ?, ?)",
        (user_id, tool, summary, details, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        if not session.get("is_admin"):
            flash("Admin access only.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


def register_user(username, email, password):
    from werkzeug.security import generate_password_hash
    conn = get_db()
    conn.execute(
        "INSERT INTO users (username, email, password_hash, is_admin, created_at) VALUES (?, ?, ?, 0, ?)",
        (username, email, generate_password_hash(password), datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def find_user(username):
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    return user
