import os
import secrets
import uuid
import random
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import check_password_hash

from utils import get_db, init_db, login_required, admin_required, register_user, find_user, log_activity
from cv_logic import analyze_leaf, diagnose as diagnose_leaf

BASE_DIR = os.path.dirname(__file__)
MODEL_DIR = os.path.join(BASE_DIR, "model")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXT = {"jpg", "jpeg", "png"}

app = Flask(__name__)
# Use a fixed SECRET_KEY in production so sessions survive restarts.
# Without one, a random key is generated per start (sessions reset on restart).
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
if not os.environ.get("SECRET_KEY"):
    print("[setup] SECRET_KEY not set; using a random per-process key. Set SECRET_KEY for production.")

init_db()

# ---------------- Load all 5 ML model bundles ----------------
_models = {}


def load_model(name):
    if name not in _models:
        path = os.path.join(MODEL_DIR, f"{name}.pkl")
        _models[name] = joblib.load(path) if os.path.exists(path) else None
    return _models[name]


# ================= Auth =================

@app.route("/")
def root():
    return redirect(url_for("home")) if "user_id" in session else redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        if not username or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))
        try:
            register_user(username, email, password)
        except Exception:
            flash("Username or email already exists.", "danger")
            return redirect(url_for("register"))
        flash("Account created. Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = find_user(username)
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["is_admin"] = bool(user["is_admin"])
            flash(f"Welcome back, {user['username']}!", "success")
            return redirect(url_for("home"))
        flash("Invalid username or password.", "danger")
        return redirect(url_for("login"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/home")
@login_required
def home():
    return render_template("home.html")


# ================= 1. Crop Recommendation =================

@app.route("/crop")
@login_required
def crop_index():
    return render_template("crop_index.html")


@app.route("/crop/predict", methods=["POST"])
@login_required
def crop_predict():
    bundle = load_model("crop_model")
    if bundle is None:
        flash("Crop model not found. Run train_models.py first.", "danger")
        return redirect(url_for("crop_index"))
    try:
        values = {f: float(request.form[f]) for f in ["nitrogen", "phosphorus", "potassium", "temperature", "humidity", "ph", "rainfall"]}
    except (KeyError, ValueError):
        flash("Please fill in all fields with valid numbers.", "danger")
        return redirect(url_for("crop_index"))

    features = bundle["features"]
    lookup = {"N": "nitrogen", "P": "phosphorus", "K": "potassium", "temperature": "temperature",
              "humidity": "humidity", "ph": "ph", "rainfall": "rainfall"}
    X = pd.DataFrame([[values[lookup[f]] for f in features]], columns=features)
    pred_encoded = bundle["model"].predict(X)[0]
    crop = bundle["encoder"].inverse_transform([pred_encoded])[0]
    confidence = round(float(max(bundle["model"].predict_proba(X)[0])) * 100, 1)

    log_activity(session["user_id"], "Crop Recommendation", f"Recommended: {crop}", str(values))
    return render_template("crop_result.html", crop=crop, confidence=confidence, values=values)


# ================= 2. Leaf Disease Detector =================

@app.route("/disease")
@login_required
def disease_index():
    return render_template("disease_index.html")


@app.route("/disease/diagnose", methods=["POST"])
@login_required
def disease_diagnose():
    file = request.files.get("leaf_image")
    if not file or file.filename == "":
        flash("Please choose a leaf image to upload.", "danger")
        return redirect(url_for("disease_index"))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_EXT:
        flash("Only .jpg, .jpeg, .png files are supported.", "danger")
        return redirect(url_for("disease_index"))

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    file.save(filepath)

    stats = analyze_leaf(filepath)
    if stats is None:
        flash("Could not read that image. Try a different file.", "danger")
        return redirect(url_for("disease_index"))

    result, confidence = diagnose_leaf(stats)

    if stats.get("leaf_coverage", 100) < 12.0:
        os.remove(filepath)
        flash("That doesn't look like a leaf photo - please upload a clear close-up of a single leaf.", "warning")
        return redirect(url_for("disease_index"))

    log_activity(session["user_id"], "Disease Detector", f"Diagnosis: {result}", str(stats))
    return render_template("disease_result.html", filename=filename, stats=stats, result=result, confidence=confidence)


# ================= 3. Smart Irrigation =================

@app.route("/irrigation")
@login_required
def irrigation_index():
    return render_template("irrigation_index.html")


@app.route("/irrigation/check", methods=["POST"])
@login_required
def irrigation_check():
    bundle = load_model("irrigation_model")
    if bundle is None:
        flash("Irrigation model not found. Run train_models.py first.", "danger")
        return redirect(url_for("irrigation_index"))
    try:
        moisture = float(request.form["moisture"])
        temp = float(request.form["temperature"])
        humidity = float(request.form["humidity"])
        rain = float(request.form["rain"])
        need = request.form["need"]
    except (KeyError, ValueError):
        flash("Please fill in all fields with valid values.", "danger")
        return redirect(url_for("irrigation_index"))
    if need not in set(bundle["need_encoder"].classes_):
        flash("Please choose a valid water need level.", "danger")
        return redirect(url_for("irrigation_index"))

    need_enc = bundle["need_encoder"].transform([need])[0]
    X = pd.DataFrame([[moisture, temp, humidity, rain, need_enc]], columns=bundle["features"])
    should_irrigate = bool(bundle["clf"].predict(X)[0])
    liters = round(max(float(bundle["reg"].predict(X)[0]), 5.0), 1) if should_irrigate else 0.0

    summary = f"Irrigate {liters}L" if should_irrigate else "No irrigation needed"
    log_activity(session["user_id"], "Smart Irrigation", summary, f"moisture={moisture} temp={temp} humidity={humidity} rain={rain} need={need}")
    return render_template("irrigation_result.html", moisture=moisture, temp=temp, humidity=humidity, rain=rain,
                            need=need, should_irrigate=should_irrigate, liters=liters)


# ================= 4. Fertilizer Advisor =================

FERT_SOIL_TYPES = ["Sandy", "Loamy", "Black", "Red", "Clayey"]
FERT_CROPS = ["Rice", "Maize", "Wheat", "Sugarcane", "Cotton", "Barley", "Millets", "Pulses"]


@app.route("/fertilizer")
@login_required
def fertilizer_index():
    return render_template("fertilizer_index.html", soil_types=FERT_SOIL_TYPES, crops=FERT_CROPS)


@app.route("/fertilizer/recommend", methods=["POST"])
@login_required
def fertilizer_recommend():
    bundle = load_model("fertilizer_model")
    if bundle is None:
        flash("Fertilizer model not found. Run train_models.py first.", "danger")
        return redirect(url_for("fertilizer_index"))
    try:
        soil = request.form["soil"]; crop = request.form["crop"]
        temp = float(request.form["temperature"]); humidity = float(request.form["humidity"])
        moisture = float(request.form["moisture"])
        n = float(request.form["nitrogen"]); p = float(request.form["phosphorous"]); k = float(request.form["potassium"])
    except (KeyError, ValueError):
        flash("Please fill in all fields with valid values.", "danger")
        return redirect(url_for("fertilizer_index"))

    soil_enc = bundle["soil_encoder"].transform([soil])[0]
    crop_enc = bundle["crop_encoder"].transform([crop])[0]
    X = pd.DataFrame([[temp, humidity, moisture, soil_enc, crop_enc, n, p, k]], columns=bundle["features"])
    pred = bundle["model"].predict(X)[0]
    fertilizer = bundle["fert_encoder"].inverse_transform([pred])[0]
    confidence = round(float(max(bundle["model"].predict_proba(X)[0])) * 100, 1)

    log_activity(session["user_id"], "Fertilizer Advisor", f"Recommended: {fertilizer}",
                 f"soil={soil} crop={crop} n={n} p={p} k={k}")
    return render_template("fertilizer_result.html", soil=soil, crop=crop, temp=temp, humidity=humidity,
                            moisture=moisture, n=n, p=p, k=k, fertilizer=fertilizer, confidence=confidence)


# ================= 5. Crop Yield Predictor =================

@app.route("/yield")
@login_required
def yield_index():
    bundle = load_model("yield_model")
    crops = list(bundle["crop_encoder"].classes_) if bundle else []
    seasons = list(bundle["season_encoder"].classes_) if bundle else []
    states = list(bundle["state_encoder"].classes_) if bundle else []
    return render_template("yield_index.html", crops=crops, seasons=seasons, states=states)


@app.route("/yield/predict", methods=["POST"])
@login_required
def yield_predict():
    bundle = load_model("yield_model")
    if bundle is None:
        flash("Yield model not found. Run train_models.py first.", "danger")
        return redirect(url_for("yield_index"))
    try:
        crop = request.form["crop"]; season = request.form["season"]; state = request.form["state"]
        area = float(request.form["area"]); rainfall = float(request.form["rainfall"])
        fertilizer = float(request.form["fertilizer"]); pesticide = float(request.form["pesticide"])
    except (KeyError, ValueError):
        flash("Please fill in all fields with valid values.", "danger")
        return redirect(url_for("yield_index"))

    crop_enc = bundle["crop_encoder"].transform([crop])[0]
    season_enc = bundle["season_encoder"].transform([season])[0]
    state_enc = bundle["state_encoder"].transform([state])[0]
    X = pd.DataFrame([[crop_enc, season_enc, state_enc, area, rainfall, fertilizer, pesticide]], columns=bundle["features"])
    pred_yield = round(float(bundle["model"].predict(X)[0]), 2)
    total_production = round(pred_yield * area, 1)

    log_activity(session["user_id"], "Yield Predictor", f"{pred_yield} t/ha - {crop}",
                 f"season={season} state={state} area={area} rainfall={rainfall}")
    return render_template("yield_result.html", crop=crop, season=season, state=state, area=area, rainfall=rainfall,
                            fertilizer=fertilizer, pesticide=pesticide, pred_yield=pred_yield, total_production=total_production)


# ================= 6. Market Price Forecaster =================

def forecast_price(bundle, commodity, days):
    latest = bundle["latest_by_commodity"]
    row = latest.loc[commodity].copy()
    commodity_enc = bundle["commodity_encoder"].transform([commodity])[0]
    lag_7, lag_14 = row["lag_7"], row["lag_14"]
    rolling_mean_7 = row["rolling_mean_7"]
    day_of_year = int(row["day_of_year"])
    current_price = row["Price_per_kg"]
    recent_window = [row["Price_per_kg"]] * 7
    predictions = []
    for _ in range(days):
        day_of_year = (day_of_year % 365) + 1
        X = pd.DataFrame([[commodity_enc, current_price, lag_7, lag_14, rolling_mean_7, day_of_year]], columns=bundle["features"])
        next_price = float(bundle["model"].predict(X)[0])
        predictions.append(round(next_price, 2))
        lag_14 = lag_7; lag_7 = current_price; current_price = next_price
        recent_window = recent_window[1:] + [next_price]
        rolling_mean_7 = float(np.mean(recent_window))
    return round(row["Price_per_kg"], 2), predictions


@app.route("/price")
@login_required
def price_index():
    bundle = load_model("price_model")
    commodities = list(bundle["latest_by_commodity"].index) if bundle else []
    return render_template("price_index.html", commodities=commodities)


@app.route("/price/forecast", methods=["POST"])
@login_required
def price_forecast():
    bundle = load_model("price_model")
    if bundle is None:
        flash("Price model not found. Run train_models.py first.", "danger")
        return redirect(url_for("price_index"))
    commodity = request.form.get("commodity")
    try:
        days = min(max(int(request.form.get("days", 1)), 1), 90)
    except ValueError:
        flash("Please enter a whole number of days.", "danger")
        return redirect(url_for("price_index"))
    latest = bundle["latest_by_commodity"]
    if commodity not in latest.index:
        flash("Unknown commodity.", "danger")
        return redirect(url_for("price_index"))

    latest_price, predictions = forecast_price(bundle, commodity, days)
    if predictions[-1] > latest_price * 1.03:
        advice = "Prices trending up - consider holding stock before selling if storage allows."
    elif predictions[-1] < latest_price * 0.97:
        advice = "Prices trending down - consider selling sooner rather than later."
    else:
        advice = "Prices look fairly stable over this period."

    log_activity(session["user_id"], "Price Forecaster", f"{commodity} +{days}d", f"latest={latest_price} forecast={predictions}")
    return render_template("price_result.html", commodity=commodity, days=days, latest_price=latest_price,
                            predictions=predictions, advice=advice)


# ================= 7. Farm Monitor (live) =================

THRESHOLDS = {"soil_moisture": (25, 70), "temperature": (15, 35), "humidity": (30, 85), "co2_ppm": (350, 1200)}
ZONE_NAMES = ["Zone-1", "Zone-2", "Zone-3"]
USER_ZONE_STATE = {}
LAST_LOG_TIME = {}


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def init_zone():
    return {"soil_moisture": random.uniform(35, 60), "temperature": random.uniform(20, 28),
            "humidity": random.uniform(45, 70), "co2_ppm": random.uniform(400, 700)}


def step_zone(z):
    z["soil_moisture"] = clamp(z["soil_moisture"] + random.uniform(-3, 3), 5, 95)
    z["temperature"] = clamp(z["temperature"] + random.uniform(-0.8, 0.8), 5, 45)
    z["humidity"] = clamp(z["humidity"] + random.uniform(-2, 2), 10, 100)
    z["co2_ppm"] = clamp(z["co2_ppm"] + random.uniform(-40, 40), 300, 2000)
    return z


def zone_status(value, key):
    lo, hi = THRESHOLDS[key]
    if value < lo or value > hi:
        return "alert"
    if value < lo * 1.1 or value > hi * 0.9:
        return "watch"
    return "ok"


@app.route("/monitor")
@login_required
def monitor_index():
    return render_template("monitor_index.html", zones=ZONE_NAMES)


@app.route("/monitor/api")
@login_required
def monitor_api():
    uid = session["user_id"]
    if uid not in USER_ZONE_STATE:
        USER_ZONE_STATE[uid] = {name: init_zone() for name in ZONE_NAMES}

    out = {}
    any_alert = False
    for name in ZONE_NAMES:
        z = step_zone(USER_ZONE_STATE[uid][name])
        statuses = {k: zone_status(z[k], k) for k in THRESHOLDS}
        zone_alert = any(v == "alert" for v in statuses.values())
        any_alert = any_alert or zone_alert
        out[name] = {**{k: round(v, 1) for k, v in z.items()}, "status": statuses, "alert": zone_alert}

    import time
    now = time.time()
    if now - LAST_LOG_TIME.get(uid, 0) >= 3:
        LAST_LOG_TIME[uid] = now
        conn = get_db()
        for name in ZONE_NAMES:
            z = out[name]
            conn.execute(
                """INSERT INTO readings (user_id, zone, soil_moisture, temperature, humidity, co2_ppm, has_alert, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (uid, name, z["soil_moisture"], z["temperature"], z["humidity"], z["co2_ppm"], int(z["alert"]),
                 datetime.utcnow().isoformat()),
            )
        conn.commit()
        conn.close()

    return jsonify({"zones": out, "any_alert": any_alert, "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})


# ================= Dashboard / History / Admin =================

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    uid = session["user_id"]
    total_activities = conn.execute("SELECT COUNT(*) AS c FROM activities WHERE user_id = ?", (uid,)).fetchone()["c"]
    per_tool = conn.execute(
        "SELECT tool, COUNT(*) AS cnt FROM activities WHERE user_id = ? GROUP BY tool ORDER BY cnt DESC", (uid,)
    ).fetchall()
    recent = conn.execute(
        "SELECT * FROM activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 8", (uid,)
    ).fetchall()
    readings_total = conn.execute("SELECT COUNT(*) AS c FROM readings WHERE user_id = ?", (uid,)).fetchone()["c"]
    readings_alerts = conn.execute("SELECT COUNT(*) AS c FROM readings WHERE user_id = ? AND has_alert = 1", (uid,)).fetchone()["c"]
    conn.close()
    return render_template("dashboard.html", total_activities=total_activities, per_tool=per_tool, recent=recent,
                            readings_total=readings_total, readings_alerts=readings_alerts)


@app.route("/history")
@login_required
def history():
    conn = get_db()
    uid = session["user_id"]
    records = conn.execute("SELECT * FROM activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 300", (uid,)).fetchall()
    conn.close()
    return render_template("history.html", records=records)


@app.route("/admin")
@admin_required
def admin():
    conn = get_db()
    users = conn.execute("SELECT id, username, email, is_admin, created_at FROM users ORDER BY created_at DESC").fetchall()
    total_activities = conn.execute("SELECT COUNT(*) AS c FROM activities").fetchone()["c"]
    per_tool = conn.execute("SELECT tool, COUNT(*) AS cnt FROM activities GROUP BY tool ORDER BY cnt DESC").fetchall()
    recent = conn.execute(
        """SELECT activities.created_at, activities.tool, activities.summary AS result, users.username
           FROM activities JOIN users ON activities.user_id = users.id
           ORDER BY activities.created_at DESC LIMIT 25"""
    ).fetchall()

    # Per-user x per-tool usage matrix: exactly which tools each user has used, and how often.
    usage_rows = conn.execute(
        """SELECT users.id AS user_id, users.username, activities.tool, COUNT(*) AS cnt,
                  MAX(activities.created_at) AS last_used
           FROM activities JOIN users ON activities.user_id = users.id
           GROUP BY users.id, activities.tool
           ORDER BY users.username, cnt DESC"""
    ).fetchall()
    conn.close()

    user_tool_usage = {}
    for row in usage_rows:
        user_tool_usage.setdefault(row["username"], []).append(
            {"tool": row["tool"], "count": row["cnt"], "last_used": row["last_used"][:19]}
        )

    return render_template("admin.html", users=users, total_users=len(users), total_activities=total_activities,
                            per_tool=per_tool, recent_predictions=recent, user_tool_usage=user_tool_usage)


@app.route("/admin/user/<int:user_id>")
@admin_required
def admin_user_detail(user_id):
    conn = get_db()
    user = conn.execute("SELECT id, username, email, is_admin, created_at FROM users WHERE id = ?", (user_id,)).fetchone()
    if user is None:
        conn.close()
        flash("User not found.", "danger")
        return redirect(url_for("admin"))
    activities = conn.execute(
        "SELECT * FROM activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 300", (user_id,)
    ).fetchall()
    readings_total = conn.execute("SELECT COUNT(*) AS c FROM readings WHERE user_id = ?", (user_id,)).fetchone()["c"]
    conn.close()
    return render_template("admin_user_detail.html", user=user, activities=activities, readings_total=readings_total)


def open_in_chrome(url):
    """Open url in Google Chrome if it can be found, otherwise in the default browser."""
    import webbrowser
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Google\Chrome\Application\chrome.exe"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "google-chrome", "google-chrome-stable", "chromium",
    ]
    for path in candidates:
        if os.path.isabs(path) and not os.path.exists(path):
            continue
        try:
            from shutil import which
            if not os.path.isabs(path) and which(path) is None:
                continue
            webbrowser.register("chrome", None, webbrowser.BackgroundBrowser(path))
            webbrowser.get("chrome").open(url)
            return True
        except Exception:
            continue
    webbrowser.open(url)  # fallback: default browser
    return False


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    # Set OPEN_BROWSER=0 to turn off the automatic browser launch.
    if os.environ.get("OPEN_BROWSER", "1") == "1":
        import threading
        url = f"http://localhost:{port}/login"
        threading.Timer(1.5, open_in_chrome, args=(url,)).start()
    app.run(host="0.0.0.0", port=port, debug=False)
