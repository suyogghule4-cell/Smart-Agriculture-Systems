"""Generates all 5 synthetic training datasets used by the combined app."""
import os
import numpy as np
import pandas as pd

os.makedirs("dataset", exist_ok=True)

# ---------- 1. Crop recommendation ----------
rng = np.random.default_rng(42)
CROPS_INFO = [
    ("rice",        80, 15, 47, 10, 40,  5, 23.5, 2.5, 82, 3,  6.4, 0.5, 240, 30),
    ("maize",       78, 20, 48, 12, 20,  5, 24.0, 4.0, 65, 8,  6.3, 0.5, 85,  25),
    ("chickpea",    40, 8,  67, 8,  80,  8, 19.0, 3.0, 17, 4,  7.3, 0.5, 80,  15),
    ("kidneybeans", 21, 6,  67, 8,  20,  5, 19.5, 3.0, 21, 4,  5.7, 0.4, 105, 20),
    ("pigeonpeas",  21, 6,  67, 8,  20,  5, 27.5, 4.0, 49, 12, 5.8, 0.6, 150, 60),
    ("mothbeans",   21, 6,  47, 7,  20,  4, 28.5, 3.0, 53, 15, 6.8, 0.5, 51,  15),
    ("mungbean",    21, 6,  47, 7,  20,  4, 28.5, 3.0, 85, 5,  6.7, 0.4, 49,  10),
    ("blackgram",   40, 6,  67, 7,  19,  4, 29.5, 3.0, 65, 9,  7.1, 0.5, 68,  15),
    ("lentil",      19, 4,  68, 6,  19,  4, 24.5, 3.0, 65, 9,  6.9, 0.5, 46,  10),
    ("pomegranate", 19, 4,  18, 4,  40,  4, 21.5, 3.0, 90, 3,  6.4, 0.4, 107, 15),
    ("banana",      100, 10, 82, 6, 50,  5, 27.5, 2.0, 80, 4,  6.0, 0.4, 105, 15),
    ("mango",       20, 5,  27, 5,  30,  5, 31.5, 2.5, 50, 7,  5.8, 0.5, 95,  20),
    ("grapes",      23, 5,  132, 6, 200, 5, 24.0, 3.0, 82, 3,  6.0, 0.4, 70,  10),
    ("watermelon",  99, 10, 17, 4,  50,  4, 25.5, 2.5, 85, 3,  6.5, 0.5, 50,  10),
    ("muskmelon",   100, 10, 17, 4,  50,  4, 28.5, 2.0, 92, 2,  6.4, 0.4, 25,  8),
    ("apple",       21, 4,  135, 6, 200, 5, 22.5, 2.0, 92, 2,  5.9, 0.4, 113, 15),
    ("orange",      20, 5,  16, 4,  10,  3, 22.5, 3.0, 92, 2,  7.0, 0.5, 110, 15),
    ("papaya",      50, 8,  59, 7,  50,  5, 33.5, 2.5, 92, 2,  6.7, 0.4, 145, 20),
    ("coconut",     22, 5,  17, 4,  31,  4, 27.5, 2.0, 95, 2,  5.9, 0.4, 175, 25),
    ("cotton",      118, 12, 46, 6, 19,  4, 24.0, 2.5, 80, 4,  6.9, 0.4, 80,  15),
    ("jute",        78, 10, 47, 6, 40,  4, 25.0, 2.0, 80, 3,  6.7, 0.4, 175, 20),
    ("coffee",      101, 10, 28, 5, 30,  4, 25.5, 2.5, 58, 8,  6.8, 0.4, 158, 25),
]
rows = []
for (crop, n_m, n_s, p_m, p_s, k_m, k_s, t_m, t_s, h_m, h_s, ph_m, ph_s, r_m, r_s) in CROPS_INFO:
    for _ in range(100):
        N = max(0, rng.normal(n_m, n_s)); P = max(0, rng.normal(p_m, p_s)); K = max(0, rng.normal(k_m, k_s))
        temperature = rng.normal(t_m, t_s)
        humidity = min(100, max(10, rng.normal(h_m, h_s)))
        ph = min(9.5, max(3.5, rng.normal(ph_m, ph_s)))
        rainfall = max(20, rng.normal(r_m, r_s))
        rows.append([round(N,2), round(P,2), round(K,2), round(temperature,6), round(humidity,6), round(ph,6), round(rainfall,6), crop])
df = pd.DataFrame(rows, columns=["N","P","K","temperature","humidity","ph","rainfall","label"]).sample(frac=1, random_state=42).reset_index(drop=True)
df.to_csv("dataset/crop_data.csv", index=False)
print("crop_data.csv:", df.shape)

# ---------- 2. Irrigation ----------
rng = np.random.default_rng(7)
N = 3000
soil_moisture = rng.uniform(5, 90, N)
temperature = rng.uniform(10, 42, N)
humidity = rng.uniform(15, 95, N)
rain_forecast_mm = rng.exponential(3, N)
crop_water_need = rng.choice(["low", "medium", "high"], N, p=[0.3, 0.4, 0.3])
need_factor = pd.Series(crop_water_need).map({"low": 0.7, "medium": 1.0, "high": 1.3}).values
threshold = 35 * need_factor - (rain_forecast_mm * 2) + (temperature - 25) * 0.5 - (humidity - 50) * 0.2
irrigate = (soil_moisture < threshold).astype(int)
water_liters = np.clip((threshold - soil_moisture) * 8 * need_factor, 0, None)
water_liters = np.where(irrigate == 1, water_liters + rng.normal(0, 5, N), 0)
water_liters = np.clip(water_liters, 0, None).round(1)
df2 = pd.DataFrame({
    "soil_moisture_pct": soil_moisture.round(1), "temperature_c": temperature.round(1),
    "humidity_pct": humidity.round(1), "rain_forecast_mm": rain_forecast_mm.round(1),
    "crop_water_need": crop_water_need, "irrigate": irrigate, "water_liters": water_liters,
})
df2.to_csv("dataset/irrigation_data.csv", index=False)
print("irrigation_data.csv:", df2.shape)

# ---------- 3. Fertilizer ----------
rng = np.random.default_rng(11)
SOIL_TYPES = ["Sandy", "Loamy", "Black", "Red", "Clayey"]
FERT_CROPS = ["Rice", "Maize", "Wheat", "Sugarcane", "Cotton", "Barley", "Millets", "Pulses"]
rows = []
for _ in range(3000):
    soil = rng.choice(SOIL_TYPES); crop = rng.choice(FERT_CROPS)
    temperature = rng.uniform(15, 40); humidity = rng.uniform(20, 90); moisture = rng.uniform(10, 70)
    n = rng.uniform(0, 140); p = rng.uniform(0, 140); k = rng.uniform(0, 140)
    deficiency = np.argmin([n, p, k])
    if deficiency == 0: fert = rng.choice(["Urea", "Ammonium Sulphate"], p=[0.7, 0.3])
    elif deficiency == 1: fert = rng.choice(["DAP", "SSP"], p=[0.6, 0.4])
    else: fert = "MOP"
    if n > 80 and p > 80 and k > 80: fert = "NPK 20-20-20"
    rows.append([soil, crop, round(temperature,1), round(humidity,1), round(moisture,1), round(n,1), round(p,1), round(k,1), fert])
df3 = pd.DataFrame(rows, columns=["Soil_Type","Crop_Type","Temperature","Humidity","Moisture","Nitrogen","Phosphorous","Potassium","Fertilizer_Name"])
df3.to_csv("dataset/fertilizer_data.csv", index=False)
print("fertilizer_data.csv:", df3.shape)

# ---------- 4. Yield ----------
rng = np.random.default_rng(21)
YIELD_CROPS = ["Rice", "Wheat", "Maize", "Sugarcane", "Cotton", "Soybean"]
SEASONS = ["Kharif", "Rabi", "Summer", "Whole Year"]
STATES = ["Punjab", "Maharashtra", "Uttar Pradesh", "Karnataka", "Tamil Nadu", "Bihar"]
BASE_YIELD = {"Rice": 3.5, "Wheat": 3.2, "Maize": 2.8, "Sugarcane": 65.0, "Cotton": 1.6, "Soybean": 1.2}
rows = []
for _ in range(3000):
    crop = rng.choice(YIELD_CROPS); season = rng.choice(SEASONS); state = rng.choice(STATES)
    area_ha = rng.uniform(1, 500); rainfall_mm = rng.uniform(300, 2500)
    fertilizer_kg_ha = rng.uniform(20, 250); pesticide_kg_ha = rng.uniform(0, 15)
    base = BASE_YIELD[crop]
    rain_factor = 1 + (rainfall_mm - 1000) / 4000
    fert_factor = 1 + (fertilizer_kg_ha - 100) / 600
    pest_penalty = 1 - pesticide_kg_ha / 200
    noise = rng.normal(1, 0.08)
    yield_t_ha = max(base * rain_factor * fert_factor * pest_penalty * noise, 0.2)
    rows.append([crop, season, state, round(area_ha,1), round(rainfall_mm,1), round(fertilizer_kg_ha,1), round(pesticide_kg_ha,2), round(yield_t_ha,2)])
df4 = pd.DataFrame(rows, columns=["Crop","Season","State","Area_hectare","Rainfall_mm","Fertilizer_kg_per_ha","Pesticide_kg_per_ha","Yield_tons_per_ha"])
df4.to_csv("dataset/yield_data.csv", index=False)
print("yield_data.csv:", df4.shape)

# ---------- 5. Market price ----------
rng = np.random.default_rng(33)
from datetime import datetime, timedelta
COMMODITIES = {"Tomato": 20, "Onion": 25, "Potato": 15, "Rice": 40, "Wheat": 28, "Maize": 18}
DAYS = 730
start_date = datetime(2024, 1, 1)
rows = []
for commodity, base_price in COMMODITIES.items():
    price = base_price
    for d in range(DAYS):
        date = start_date + timedelta(days=d)
        season = 5 * np.sin(2 * np.pi * d / 365 + hash(commodity) % 10)
        trend = 0.01 * d / 30
        shock = rng.normal(0, 1.5)
        if rng.random() < 0.01:
            shock += rng.choice([-1, 1]) * rng.uniform(8, 15)
        price = max(price + 0.3 * season / 30 + trend / 30 + shock * 0.3, 3)
        rows.append([date.strftime("%Y-%m-%d"), commodity, round(price, 2)])
df5 = pd.DataFrame(rows, columns=["Date", "Commodity", "Price_per_kg"])
df5.to_csv("dataset/price_history.csv", index=False)
print("price_history.csv:", df5.shape)

print("\nAll datasets generated.")
