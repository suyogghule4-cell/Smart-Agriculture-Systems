"""Leaf health analysis (color-distribution heuristic, no training data needed)."""
import cv2
import numpy as np


# Minimum share of the photo that must look leaf-like (green/yellow/brown
# in HSV) before we trust a diagnosis at all. Below this, the photo is
# probably not a leaf/plant close-up.
MIN_LEAF_COVERAGE_PCT = 12.0


def analyze_leaf(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return None
    img = cv2.resize(img, (400, 400))
    total_pixels = img.shape[0] * img.shape[1]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    leaf_mask = cv2.inRange(hsv, (15, 30, 30), (95, 255, 255))

    # Clean up speckle noise, then require the leaf-colored area to form one
    # solid connected blob (a real leaf), not scattered pixels of similar hue
    # spread across a busy/noisy photo.
    kernel = np.ones((5, 5), np.uint8)
    cleaned_mask = cv2.morphologyEx(leaf_mask, cv2.MORPH_OPEN, kernel)
    contours, _ = cv2.findContours(cleaned_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    largest_blob_area = max((cv2.contourArea(c) for c in contours), default=0)

    leaf_pixel_count = int(np.sum(leaf_mask > 0))
    leaf_coverage = largest_blob_area / total_pixels * 100
    leaf_pixels = max(leaf_pixel_count, 1)

    healthy_green = cv2.inRange(hsv, (35, 40, 40), (85, 255, 255))
    yellowing = cv2.inRange(hsv, (20, 40, 40), (34, 255, 255))
    brown_spots = cv2.inRange(hsv, (5, 40, 20), (19, 255, 200))
    dark_spots = cv2.inRange(hsv, (0, 0, 0), (180, 255, 50)) & leaf_mask

    return {
        "green": round(np.sum(healthy_green > 0) / leaf_pixels * 100, 1),
        "yellow": round(np.sum(yellowing > 0) / leaf_pixels * 100, 1),
        "brown": round(np.sum(brown_spots > 0) / leaf_pixels * 100, 1),
        "dark_spots": round(np.sum(dark_spots > 0) / leaf_pixels * 100, 1),
        "leaf_coverage": round(leaf_coverage, 1),
    }


def diagnose(stats):
    if stats.get("leaf_coverage", 100) < MIN_LEAF_COVERAGE_PCT:
        return "No leaf detected - please upload a clear close-up photo of a single leaf", 0

    green, yellow, brown, dark = stats["green"], stats["yellow"], stats["brown"], stats["dark_spots"]
    if green >= 70 and yellow < 10 and brown < 5 and dark < 3:
        return "Healthy", min(round(90 + min(green - 70, 10)), 99)
    if brown >= 15 or dark >= 12:
        return "Possible fungal blight / leaf spot disease", min(round(60 + min(brown + dark, 35)), 99)
    if yellow >= 25:
        return "Possible nutrient deficiency (nitrogen) / chlorosis", min(round(55 + min(yellow, 35)), 99)
    if yellow >= 12 and brown >= 5:
        return "Possible early-stage disease or nutrient stress", min(round(50 + min(yellow + brown, 40)), 99)
    return "Mostly healthy, minor stress detected", 65
